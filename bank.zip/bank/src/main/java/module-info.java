module com.bank {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.bank.entity to javafx.base;
    opens com.bank.controller to javafx.fxml;
    exports com.bank;
    exports com.bank.service;
    exports com.bank.entity;
    exports com.bank.cache;
}