package com.bank.utils;

import com.bank.App;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

    public static boolean verifyIsEmpty(String content, String field) {
        if (stringIsEmpty(content)) {
            showPrompt(field + " is empty.", "Error");
            return true;
        }
        return false;
    }

    public static boolean stringIsEmpty(String content) {
        if (content == null || content.trim().length() == 0){
            return true;
        }
        return false;
    }

    public static void showPrompt(String prompt, String type) {
        Alert.AlertType alertType;
        if ("Success".equals(type)) {
            alertType = Alert.AlertType.INFORMATION;
        } else {
            alertType = Alert.AlertType.ERROR;
        }
        Alert alert = new Alert(alertType);
        alert.setTitle(type);
        alert.setHeaderText(null);
        alert.setContentText(prompt);
        alert.showAndWait();
    }

    public static Object showPage(String fxml, double width, double height, String title) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml));
        Scene scene = new Scene(fxmlLoader.load(), width, height);
        Stage stage = new Stage();
        stage.setTitle(title);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
        return fxmlLoader.getController();
    }

    public static boolean isNumber(String content) {
        String regex = "[+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(content);
        return matcher.matches();
    }

    public static String openInputDialog(String title, String headerText, String prompt, String label) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle(title);
        dialog.setHeaderText(headerText);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);

        TextField textField = new TextField();
        textField.setPromptText(prompt);

        grid.add(new Label(label), 0, 0);
        grid.add(textField, 1, 0);

        dialog.getDialogPane().setContent(grid);

        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        Platform.runLater(() -> textField.requestFocus());

        Optional<ButtonType> result = dialog.showAndWait();
        if(result.isPresent() && result.get().getButtonData().isCancelButton()){
            return null;
        }
        return textField.getText() == null ? "":textField.getText() ;
    }
}
