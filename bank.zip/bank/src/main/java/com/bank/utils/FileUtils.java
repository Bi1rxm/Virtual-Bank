package com.bank.utils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class FileUtils {

    public static List<String> readFile(String path) {
        List<String> list = new ArrayList<>();
        File file = new File(path);
        if (file.exists()) {
            try (BufferedReader br = new BufferedReader(new FileReader(path))) {
                String line;
                while ((line = br.readLine()) != null) {
                    list.add(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return list;
    }

    public static void writeFile(String path, String content) throws IOException {
        if (!Files.exists(Paths.get(path))) {
            new File(path).createNewFile();
        }
        if (Files.size(Paths.get(path)) > 0) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(path, true))) {
                writer.write(content);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
                writer.write(content);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void writeFileBatch(String path, List<String> contentList) throws IOException {
        if (Files.exists(Paths.get(path)) && Files.size(Paths.get(path)) > 0) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(path, true))) {
                if (contentList != null && contentList.size() > 0) {
                    for (int i = 0; i < contentList.size(); i++) {
                        writer.write(contentList.get(i));
                        writer.newLine();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
                if (contentList != null && contentList.size() > 0) {
                    for (int i = 0; i < contentList.size(); i++) {
                        writer.write(contentList.get(i));
                        writer.newLine();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void deleteFile(List<String> targetIds, String path) throws IOException {
        File file = new File(path);
        if (file != null && file.exists()) {
            List<String> allContent = readFile(path);
            List<String> result = new ArrayList<>();
            for (int i = 0; i < allContent.size(); i++) {
                String line = allContent.get(i);
                if (line != null) {
                    String[] arr = line.split(",");
                    if (arr.length > 0 && targetIds.indexOf(arr[0]) == -1) {
                        result.add(line);
                    }
                }
            }
            file.delete();
            writeFileBatch(path, result);
        }
    }

    public static void updateFile(String path, String targetId, String content) throws IOException {
        File file = new File(path);
        if (file != null && file.exists()) {
            List<String> allContent = readFile(path);
            boolean isUpdate = false;
            for (int i = 0; i < allContent.size(); i++) {
                String line = allContent.get(i);
                if (line != null) {
                    String[] arr = line.split(",");
                    if (arr.length > 0 && arr[0].equals(targetId)) {
                        allContent.set(i, content);
                        isUpdate = true;
                        break;
                    }
                }
            }
            if (isUpdate) {
                file.delete();
                writeFileBatch(path, allContent);
            }
        }
    }
}

