package com.bank.controller;

import com.bank.entity.Account;
import com.bank.service.AccountService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListCell;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.util.List;

public class TransferMoneyController {

    public ComboBox<String> payer;
    public TextField amount;
    public TextField payee;
    public PasswordField password;

    List<Account> accountList = null;
    AccountService accountService = new AccountService();

    public void initialize() {
        accountList = accountService.findAllCurrentUserAccount();
        if (accountList != null && accountList.size() > 0) {
            payer.getItems().clear();
            for (Account account : accountList) {
                payer.getItems().add(account.getNumber());
            }
        }
    }

    public void confirm(ActionEvent actionEvent) {
        String payerValue = payer.getValue();
        String amountText = amount.getText();
        String payeeText = payee.getText();
        String passwordText = password.getText();
        if (Utils.verifyIsEmpty(payerValue, "Payer")) {
            return;
        }
        if (Utils.verifyIsEmpty(payeeText, "Payee")) {
            return;
        }
        if (Utils.verifyIsEmpty(passwordText, "Password")) {
            return;
        }
        if (!Utils.isNumber(amountText)) {
            Utils.showPrompt("Amount is invalid.", "Error");
            return;
        }

        Account payerAccount = null;
        for (Account account : accountList) {
            if (account.getNumber().equals(payerValue)) {
                payerAccount = account;
                break;
            }
        }
        Double amountInDouble = Double.valueOf(amountText);
        if (payerAccount.getBalance() < amountInDouble) {
            Utils.showPrompt("Account balance is insufficient.\n", "Error");
            return;
        }
        if (payerAccount.getStatus().equals("frozen")) {
            Utils.showPrompt("Account has been frozen.", "Error");
            return;
        }
        if (!payerAccount.getPassword().equals(passwordText)) {
            Utils.showPrompt("Password is incorrect.", "Error");
            return;
        }
        Account payeeAccount = accountService.findAccountByNumber(payeeText);
        if (payeeAccount == null) {
            Utils.showPrompt("Payee is not found.","Error");
            return;
        }
        accountService.transferMoney(payerAccount, payeeAccount, amountInDouble);
        Utils.showPrompt("Transfer Successful", "Success");
    }
}
