package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.Config;
import com.bank.service.ConfigService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

public class SetGoal {

    public TextField savingGoal;
    public TextField currentGoal;

    ConfigService configService = new ConfigService();
    Config savingGoalConfig ;
    Config currentGoalConfig ;

    public void initialize() {
        String username = Cache.getInstance().getLoginUser().getUsername();
        savingGoalConfig = configService.findConfigByType("savingGoal", username);
        if (savingGoalConfig != null) {
            savingGoal.setText(savingGoalConfig.getValue());
        }
        currentGoalConfig = configService.findConfigByType("currentGoal", username);
        if (currentGoalConfig != null) {
            currentGoal.setText(currentGoalConfig.getValue());
        }
    }

    public void confirm(ActionEvent actionEvent) {
        String savingGoalText = savingGoal.getText();
        String currentGoalText = currentGoal.getText();
        if (!Utils.isNumber(savingGoalText)) {
            Utils.showPrompt("Saving goal is invalid.", "Error");
            return;
        }
        if (!Utils.isNumber(currentGoalText)) {
            Utils.showPrompt("Current goal is invalid.", "Error");
            return;
        }
        String username = Cache.getInstance().getLoginUser().getUsername();
        Config newSavingGoalConfig = new Config("savingGoal", savingGoalText, username);
        Config newCurrentGoalConfig = new Config("currentGoal", currentGoalText, username);
        if ((savingGoalConfig == null ? configService.save(newSavingGoalConfig) : configService.update(savingGoalConfig, savingGoalText)) &&
                (currentGoalConfig == null ? configService.save(newCurrentGoalConfig) : configService.update(currentGoalConfig, currentGoalText))) {
            this.savingGoalConfig = newSavingGoalConfig;
            this.currentGoalConfig = newCurrentGoalConfig;
            Utils.showPrompt("Set Goal Successful", "Success");
        } else {
            Utils.showPrompt("Failed to Set Goal", "Error");
        }
    }
}
