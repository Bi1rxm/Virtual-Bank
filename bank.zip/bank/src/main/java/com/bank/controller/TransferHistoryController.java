package com.bank.controller;

import com.bank.service.AccountService;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.MapValueFactory;

import java.util.Map;

public class TransferHistoryController {

    public TableColumn<Map<String, String>, String> accountNumber;
    public TableColumn<Map<String, String>, String> amount;
    public TableColumn<Map<String, String>, String> type;
    public TableColumn<Map<String, String>, String> time;
    public TableView<Map<String, String>> tableView;

    AccountService accountService = new AccountService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        accountNumber.setCellValueFactory(new MapValueFactory("accountNumber"));
        amount.setCellValueFactory(new MapValueFactory("amount"));
        type.setCellValueFactory(new MapValueFactory("type"));
        time.setCellValueFactory(new MapValueFactory("time"));
        tableView.setItems(FXCollections.observableArrayList(accountService.findAllCurrentUserTransferHistory()));
    }
}
