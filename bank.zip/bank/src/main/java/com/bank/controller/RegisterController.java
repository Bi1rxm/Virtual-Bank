package com.bank.controller;

import com.bank.dao.UserDao;
import com.bank.entity.User;
import com.bank.service.UserService;
import com.bank.utils.Utils;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import java.util.regex.Pattern;

public class RegisterController {

    public TextField username;
    public PasswordField password;
    public PasswordField confirmPassword;
    public TextField phone;
    public TextField firstName;
    public TextField lastName;
    public VBox registerLayout;
    public DatePicker birthday;
    public TextField address;

    private UserService userService = new UserService();

    public void register() throws IOException {
        String usernameVal = username.getText();
        String passwordVal = password.getText();
        String confirmPasswordVal = confirmPassword.getText();
        String phoneVal = phone.getText();
        String firstNameVal = firstName.getText();
        String lastNameVal = lastName.getText();
        LocalDate birthdayVal = birthday.getValue();
        String addressVal = address.getText();

        if (Utils.verifyIsEmpty(usernameVal, "Username")) {
            return;
        }
        if (Utils.verifyIsEmpty(passwordVal, "Password")) {
            return;
        }
        if (Utils.verifyIsEmpty(confirmPasswordVal, "Confirm Password")) {
            return;
        }
        if (Utils.verifyIsEmpty(phoneVal, "Phone")) {
            return;
        }
        if (Utils.verifyIsEmpty(firstNameVal, "First Name")) {
            return;
        }
        if (Utils.verifyIsEmpty(lastNameVal, "Last Name")) {
            return;
        }
        if (birthdayVal == null) {
            Utils.showPrompt("Birthday is empty.", "Error");
            return;
        }
        if (Utils.verifyIsEmpty(addressVal, "Address")) {
            return;
        }
        if (!Pattern.matches("\\d+", phoneVal)) {
            Utils.showPrompt("Phone is invalid.", "Error");
            return;
        }
        if (!passwordVal.equals(confirmPasswordVal)) {
            Utils.showPrompt("The confirmed password does not match the password.", "Error");
            return;
        }

        User user = userService.findUserByUserName(usernameVal);
        if (user != null) {
            Utils.showPrompt("The username already exists.", "Error");
            return;
        }
        user = new User(UUID.randomUUID().toString(), usernameVal, passwordVal, phoneVal, firstNameVal, lastNameVal,
                addressVal, birthdayVal.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), "customer");
        if (userService.save(user)) {
            Utils.showPrompt("Registration Successful", "Success");
            cancel();
        } else {
            Utils.showPrompt("Registration Failed", "Error");
        }
    }

    public void cancel() {
        Stage stage = (Stage) registerLayout.getScene().getWindow();
        stage.close();
    }
}
