package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.User;
import com.bank.service.UserService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Pattern;

public class ModifyBasicInfo {

    public TextField username;
    public TextField phone;
    public TextField firstName;
    public TextField lastName;
    public TextField address;
    public DatePicker birthday;

    private UserService userService = new UserService();

    public void initialize() {
        User loginUser = Cache.getInstance().getLoginUser();
        username.setText(loginUser.getUsername());
        username.setEditable(false);
        phone.setText(loginUser.getPhoneNumber());
        firstName.setText(loginUser.getFirstName());
        lastName.setText(loginUser.getLastName());
        address.setText(loginUser.getAddress());
        birthday.setValue(LocalDate.parse(loginUser.getBirthday()));
    }

    public void confirm(ActionEvent actionEvent) {
        String phoneVal = phone.getText();
        String firstNameVal = firstName.getText();
        String lastNameVal = lastName.getText();
        LocalDate birthdayVal = birthday.getValue();
        String addressVal = address.getText();

        if (Utils.verifyIsEmpty(phoneVal, "Phone")) {
            return;
        }
        if (!Pattern.matches("\\d+", phoneVal)) {
            Utils.showPrompt("Phone number is invalid.", "Error");
            return;
        }
        if (Utils.verifyIsEmpty(firstNameVal, "First Name")) {
            return;
        }
        if (Utils.verifyIsEmpty(lastNameVal, "Last Name")) {
            return;
        }
        if (Utils.verifyIsEmpty(addressVal, "Address")) {
            return;
        }
        if (birthdayVal == null) {
            Utils.showPrompt("Birthday is empty.", "Error");
            return;
        }

        User loginUser = Cache.getInstance().getLoginUser();
        loginUser.setPhoneNumber(phoneVal);
        loginUser.setFirstName(firstNameVal);
        loginUser.setLastName(lastNameVal);
        loginUser.setBirthday(birthdayVal.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        loginUser.setAddress(addressVal);

        if (userService.update(loginUser)) {
            Utils.showPrompt("Update Successful", "Success");
            initialize();
        } else {
            Utils.showPrompt("Failed to Update", "Error");
        }
    }
}
