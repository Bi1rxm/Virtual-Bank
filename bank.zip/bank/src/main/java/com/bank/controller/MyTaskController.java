package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.Task;
import com.bank.service.AccountService;
import com.bank.service.TaskService;
import com.bank.utils.Utils;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class MyTaskController {

    public TableColumn id;
    public TableColumn description;
    public TableColumn dueDate;
    public TableColumn reward;

    public TableView<Task> tableView;

    TaskService taskService = new TaskService();

    AccountService accountService = new AccountService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        dueDate.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        reward.setCellValueFactory(new PropertyValueFactory<>("reward"));
        tableView.setItems(FXCollections.observableArrayList(taskService.findAllWaitForCompletionTask()));
    }

    public void complete(ActionEvent actionEvent) {
        Task selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Utils.showPrompt("Please select a row.", "Error");
            return;
        }
        Account account = accountService.findAccountByTypeAndUsername("current", selectedItem.getReceiver());
        if (account == null) {
            Utils.showPrompt("Please apply for a current account first.", "Error");
            return;
        }
        if (taskService.complete(selectedItem)) {
            Utils.showPrompt("Complete Successful", "Success");
            tableView.setItems(FXCollections.observableArrayList(taskService.findAllWaitForCompletionTask()));
        } else {
            Utils.showPrompt("Failed to Complete", "Error");
        }
    }
}
