package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.User;
import com.bank.service.UserService;
import com.bank.utils.Utils;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    public TextField username;
    public PasswordField password;
    public VBox loginVbox;

    private UserService userService = new UserService();

    public void login() throws IOException {
        String usernameVal = username.getText();
        String passwordVal = password.getText();
        if (Utils.verifyIsEmpty(usernameVal, "Username")) {
            return;
        }
        if (Utils.verifyIsEmpty(passwordVal, "Password")) {
            return;
        }
        User user = userService.login(usernameVal, passwordVal);
        if (user == null) {
            Utils.showPrompt("Incorrect username or password.", "Error");
            return;
        }

        Utils.showPrompt("Login Successful", "Success");
        Utils.showPage("main.fxml", 800, 600, "Virtual Bank");
        Stage stage = (Stage) loginVbox.getScene().getWindow();
        stage.close();
    }

    public void register() throws IOException {
        Utils.showPage("register.fxml", 600, 400, "Register");
    }
}
