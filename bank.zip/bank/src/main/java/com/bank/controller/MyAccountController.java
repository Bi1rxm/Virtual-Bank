package com.bank.controller;

import com.bank.App;
import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.Config;
import com.bank.service.AccountService;
import com.bank.service.ConfigService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class MyAccountController {

    public Label currentAccountBalance;
    public Label currentAccountNumber;
    public Label savingAccountBalance;
    public Label savingAccountNumber;
    public Label savingAccountSchedule;
    public VBox savingAccountVBox;
    public VBox currentAccountVBox;
    public HBox parentHBox;
    public Label currentAccountSchedule;
    public Label savingAccountStatus;
    public Label currentAccountStatus;

    AccountService accountService = new AccountService();

    ConfigService configService = new ConfigService();

    public void initialize() {
        String username = Cache.getInstance().getLoginUser().getUsername();
        Account savingAccount = accountService.findAccountByTypeAndUsername("saving", username);
        Account currentAccount = accountService.findAccountByTypeAndUsername("current", username);
        if (savingAccount == null) {
            parentHBox.getChildren().remove(savingAccountVBox);
        } else {
            savingAccountNumber.setText(savingAccount.getNumber());
            savingAccountBalance.setText(String.valueOf(savingAccount.getBalance()));
            savingAccountStatus.setText(savingAccount.getStatus());
            Config savingGoalConfig = configService.findConfigByType("savingGoal", username);
            if (savingGoalConfig == null || Double.parseDouble(savingGoalConfig.getValue()) == 0) {
                savingAccountSchedule.setText("0%     Goal($): " + 0);
            } else {
                savingAccountSchedule.setText(new BigDecimal(savingAccount.getBalance() * 100).divide(new BigDecimal(
                        savingGoalConfig.getValue()), 2, RoundingMode.HALF_UP) + "%     Goal($): " + savingGoalConfig.getValue());
            }
        }
        if (currentAccount == null) {
            parentHBox.getChildren().remove(currentAccountVBox);
        } else {
            currentAccountNumber.setText(currentAccount.getNumber());
            currentAccountBalance.setText(String.valueOf(currentAccount.getBalance()));
            currentAccountStatus.setText(currentAccount.getStatus());
            Config currentGoalConfig = configService.findConfigByType("currentGoal", username);
            if (currentGoalConfig == null || Double.parseDouble(currentGoalConfig.getValue()) == 0) {
                currentAccountSchedule.setText("0%     Goal($): " + 0);
            } else {
                currentAccountSchedule.setText(new BigDecimal(currentAccount.getBalance() * 100).divide(new BigDecimal(
                        currentGoalConfig.getValue()),2, RoundingMode.HALF_UP) + "%     Goal($): " + currentGoalConfig.getValue());
            }
        }
    }

    public void currentAccountChangePassword(ActionEvent actionEvent) throws IOException {
        ChangePasswordController controller = (ChangePasswordController) Utils.showPage(
                "changePassword.fxml", 600, 400, "Current Account Change Password");
        controller.setType("currentAccountChangePassword");
    }

    public void currentAccountCloseAccount(ActionEvent actionEvent) {
        String username = Cache.getInstance().getLoginUser().getUsername();
        Account account = accountService.findAccountByTypeAndUsername("current", username);
        closeAccount(account);
    }

    public void savingAccountChangePassword(ActionEvent actionEvent) throws IOException {
        ChangePasswordController controller = (ChangePasswordController) Utils.showPage(
                "changePassword.fxml", 600, 400, "Saving Account Change Password");
        controller.setType("savingAccountChangePassword");
    }

    public void savingAccountCloseAccount(ActionEvent actionEvent) {
        String username = Cache.getInstance().getLoginUser().getUsername();
        Account account = accountService.findAccountByTypeAndUsername("saving", username);
        closeAccount(account);
    }

    private void closeAccount(Account account) {
        if (account.getBalance() == 0) {
            if (accountService.delete(account)) {
                Utils.showPrompt("Close Successful", "Success");
                initialize();
            } else {
                Utils.showPrompt("Failed to Close", "Error");
            }
        } else {
            Utils.showPrompt("Account balance is not zero.", "Error");
        }
    }
}
