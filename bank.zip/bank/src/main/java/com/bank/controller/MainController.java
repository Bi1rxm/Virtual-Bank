package com.bank.controller;

import com.bank.App;
import com.bank.cache.Cache;
import com.bank.utils.Utils;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;

public class MainController {

    public VBox pageContainer;
    public MenuBar menus;
    public BorderPane main;

    public void initialize() throws IOException {
        Map<String, com.bank.entity.Menu> roleMenu = Cache.getInstance().getRoleMenu();
        ObservableList<Menu> allMenus = menus.getMenus();
        for (Menu menu : allMenus) {
            if (roleMenu.get(menu.getText()) == null) {
                menu.setVisible(false);
            } else {
                ObservableList<MenuItem> items = menu.getItems();
                for (MenuItem item : items) {
                    if (roleMenu.get(item.getText()) == null) {
                        item.setVisible(false);
                    }
                }
            }
        }
    }

    public void changePage(ActionEvent actionEvent) throws IOException {
        pageContainer.getChildren().clear();
        MenuItem source = (MenuItem) actionEvent.getSource();
        com.bank.entity.Menu menu = Cache.getInstance().getMenu(source.getText());
        if (menu != null) {
            if (menu.getName().equals("Quit")) {
                Utils.showPage("login.fxml", 400, 260, "Virtual Bank");
                Stage stage = (Stage) main.getScene().getWindow();
                stage.close();
            } else {
                pageContainer.getChildren().add(getPageContent(menu.getTemplateName()));
            }
        }
    }

    private Node getPageContent(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml));
        return fxmlLoader.load();
    }
}
