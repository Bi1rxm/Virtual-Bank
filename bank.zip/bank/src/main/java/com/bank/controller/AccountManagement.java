package com.bank.controller;

import com.bank.entity.Account;
import com.bank.service.AccountService;
import com.bank.utils.Utils;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class AccountManagement {

    public TableView<Account> tableView;
    public TableColumn<Account, String> accountNumber;
    public TableColumn<Account, String> username;
    public TableColumn<Account, String> type;
    public TableColumn<Account, String> status;
    public TableColumn balance;

    AccountService accountService = new AccountService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        accountNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
        username.setCellValueFactory(new PropertyValueFactory<>("username"));
        balance.setCellValueFactory(new PropertyValueFactory<>("balance"));
        type.setCellValueFactory(new PropertyValueFactory<>("type"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        tableView.setItems(FXCollections.observableArrayList(accountService.findAllAccount()));
    }

    public void save(ActionEvent actionEvent) {
        Account account = validSelectRow();
        if (account != null) {
            String amount = Utils.openInputDialog("Save Money", "Please input the amount of money you want to save.",
                    "Please input the amount.", "Amount($):");
            if(amount == null){
                return;
            }
            if (!Utils.isNumber(amount)) {
                Utils.showPrompt("Input amount is invalid.", "Error");
                return;
            }
            if (accountService.saveMoney(Double.valueOf(amount), account)) {
                Utils.showPrompt("Save Successful", "Success");
                tableView.refresh();
            } else {
                Utils.showPrompt("Failed to Save", "Error");
            }
        }
    }

    private Account validSelectRow() {
        Account selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Utils.showPrompt("Please select a row.", "Error");
        }
        return selectedItem;
    }

    public void withdraw(ActionEvent actionEvent) {
        Account account = validSelectRow();
        if (account != null) {
            String amount = Utils.openInputDialog("WithDraw Money", "Please input the amount of money you want to withdraw.",
                    "Please input the amount.", "Amount($):");
            if(amount == null){
                return;
            }
            if (!Utils.isNumber(amount)) {
                Utils.showPrompt("Input amount is invalid.", "Error");
                return;
            }
            Double amountInDouble = Double.valueOf(amount);
            if (account.getBalance() < amountInDouble) {
                Utils.showPrompt("Balance is not enough.", "Error");
                return;
            }
            if (accountService.withdrawMoney(amountInDouble, account)) {
                Utils.showPrompt("Withdraw Successful", "Success");
                tableView.refresh();
            } else {
                Utils.showPrompt("Failed to Withdraw", "Error");
            }
        }
    }

    public void freeze(ActionEvent actionEvent) {
        Account account = validSelectRow();
        if (account != null) {
            if (!account.getStatus().equals("normal")) {
                Utils.showPrompt("Account has already been frozen.", "Error");
                return;
            }
            if (accountService.freeze(account)) {
                Utils.showPrompt("Freeze Successful", "Success");
                tableView.refresh();
            } else {
                Utils.showPrompt("Failed to Freeze", "Error");
            }
        }
    }

    public void thaw(ActionEvent actionEvent) {
        Account account = validSelectRow();
        if (account != null) {
            if (!account.getStatus().equals("frozen")) {
                Utils.showPrompt("Account status is normal.", "Error");
                return;
            }
            if (accountService.thaw(account)) {
                Utils.showPrompt("Thaw Successful", "Success");
                tableView.refresh();
            } else {
                Utils.showPrompt("Failed to Thaw", "Error");
            }
        }
    }

    public void settle(ActionEvent actionEvent) {
        accountService.settle();
        Utils.showPrompt("Interest Settle Successful","Success");
        tableView.setItems(FXCollections.observableArrayList(accountService.findAllAccount()));
    }
}
