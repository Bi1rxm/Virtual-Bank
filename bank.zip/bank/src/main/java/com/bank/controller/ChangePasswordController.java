package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.User;
import com.bank.service.AccountService;
import com.bank.service.UserService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.regex.Pattern;

public class ChangePasswordController {

    private String type = "userChangePassword";
    public PasswordField oldPassword;
    public PasswordField newPassword;
    public PasswordField confirmNewPassword;
    public VBox changePasswordVBox;

    public void setType(String type) {
        this.type = type;
    }

    private UserService userService = new UserService();

    private AccountService accountService = new AccountService();

    public void confirm(ActionEvent actionEvent) throws IOException {
        String oldPasswordText = oldPassword.getText();
        String newPasswordText = newPassword.getText();
        String confirmNewPasswordText = confirmNewPassword.getText();
        if (Utils.verifyIsEmpty(oldPasswordText, "Old Password")) {
            return;
        }
        if (Utils.verifyIsEmpty(newPasswordText, "New Password")) {
            return;
        }
        if (Utils.verifyIsEmpty(confirmNewPasswordText, "Confirm New Password")) {
            return;
        }
        if (!newPasswordText.equals(confirmNewPasswordText)) {
            Utils.showPrompt("Two new passwords do not match.", "Error");
            return;
        }
        if (type.equals("userChangePassword")) {
            User loginUser = Cache.getInstance().getLoginUser();
            if (!loginUser.getPassword().equals(oldPasswordText)) {
                Utils.showPrompt("Old password is wrong.", "Error");
                return;
            }
            loginUser.setPassword(newPasswordText);
            if (userService.update(loginUser)) {
                Utils.showPrompt("Update Successful", "Success");
                Utils.showPage("login.fxml", 400, 260, "Virtual Bank");
                Stage stage = (Stage) changePasswordVBox.getScene().getWindow();
                stage.close();
            } else {
                Utils.showPrompt("Failed to Update", "Error");
            }
        } else {
            Account account = null;
            if (!Pattern.matches("\\d{6}", newPasswordText)) {
                Utils.showPrompt("New password is invalid.", "Error");
                return;
            }
            String username = Cache.getInstance().getLoginUser().getUsername();
            if ("currentAccountChangePassword".equals(type)) {
                account = accountService.findAccountByTypeAndUsername("current", username);
            } else if ("savingAccountChangePassword".equals(type)) {
                account = accountService.findAccountByTypeAndUsername("saving", username);
            }
            if (account != null) {
                if (!account.getPassword().equals(oldPasswordText)) {
                    Utils.showPrompt("Old password is wrong.", "Error");
                    return;
                }
                account.setPassword(newPasswordText);
                if (accountService.update(account)) {
                    Utils.showPrompt("Update Successful", "Success");
                } else {
                    Utils.showPrompt("Failed to Update", "Error");
                }
                Stage stage = (Stage) changePasswordVBox.getScene().getWindow();
                stage.close();
            }
        }
    }
}
