package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.AccountApply;
import com.bank.service.AccountService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;

import java.util.regex.Pattern;

public class ApplyAccountController {

    AccountService accountService = new AccountService();

    public ComboBox<String> type;
    public PasswordField password;
    public PasswordField confirmPassword;

    public void confirm(ActionEvent actionEvent) {

        String typeValue = type.getValue();
        String passwordText = password.getText();
        String confirmPasswordText = confirmPassword.getText();
        if (Utils.verifyIsEmpty(typeValue, "Type")) {
            return;
        }
        if (Utils.verifyIsEmpty(passwordText, "Password")) {
            return;
        }
        if (Utils.verifyIsEmpty(confirmPasswordText, "Confirm Password")) {
            return;
        }
        if (!passwordText.equals(confirmPasswordText)) {
            Utils.showPrompt("The confirmed password is not the same.","Error");
            return;
        }
        if (!Pattern.matches("\\d{6}", passwordText)) {
            Utils.showPrompt("Password is invalid.", "Error");
            return;
        }
        String username = Cache.getInstance().getLoginUser().getUsername();

        Account account = accountService.findAccountByTypeAndUsername(typeValue, username);
        if (account != null) {
            Utils.showPrompt("You have already got a " + typeValue + " account.", "Error");
            return;
        }

        AccountApply accountApply = accountService.findApplyByTypeAndUsername(typeValue, username);
        if (accountApply != null) {
            Utils.showPrompt("You have already applied a "+typeValue+" account.", "Error");
            return;
        }
        if (accountService.save(new AccountApply(passwordText, typeValue, username))) {
            Utils.showPrompt("Apply Successful", "Success");
        } else {
            Utils.showPrompt("Failed to Apply", "Error");
        }
    }
}
