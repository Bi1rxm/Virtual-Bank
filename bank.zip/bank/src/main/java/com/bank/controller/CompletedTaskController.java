package com.bank.controller;

import com.bank.entity.Task;
import com.bank.service.AccountService;
import com.bank.service.TaskService;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class CompletedTaskController {

    public TableColumn id;
    public TableColumn description;
    public TableColumn reward;
    public TableView<Task> tableView;
    public TableColumn status;

    TaskService taskService = new TaskService();

    AccountService accountService = new AccountService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        status.setCellValueFactory(new PropertyValueFactory<>("status"));
        reward.setCellValueFactory(new PropertyValueFactory<>("reward"));
        tableView.setItems(FXCollections.observableArrayList(taskService.findAllAuditedTask()));
    }
}
