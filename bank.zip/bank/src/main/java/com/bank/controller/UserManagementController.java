package com.bank.controller;

import com.bank.entity.User;
import com.bank.service.UserService;
import com.bank.utils.Utils;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class UserManagementController {

    public TableView<User> tableView;
    public TableColumn<User, String> userName;
    public TableColumn<User, String> phone;
    public TableColumn<User, String> firstName;
    public TableColumn<User, String> lastName;
    public TableColumn<User, String> address;
    public TableColumn<User, String> role;
    public TableColumn<User, String> birthday;
    private UserService userService = new UserService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        userName.setCellValueFactory(new PropertyValueFactory<>("username"));
        phone.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        firstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        address.setCellValueFactory(new PropertyValueFactory<>("address"));
        role.setCellValueFactory(new PropertyValueFactory<>("role"));
        birthday.setCellValueFactory(new PropertyValueFactory<>("birthday"));
        tableView.setItems(FXCollections.observableArrayList(userService.findAllUser()));
    }

    public void changeRole(ActionEvent actionEvent) {
        User selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Utils.showPrompt("Please select a row.", "Error");
            return;
        }
        selectedItem.setRole(selectedItem.getRole().equals("customer") ? "employee" : "customer");
        if (userService.update(selectedItem)) {
            Utils.showPrompt("Change Successful", "Success");
            tableView.refresh();
        } else {
            Utils.showPrompt("Failed to Change","Error");
        }
    }
}
