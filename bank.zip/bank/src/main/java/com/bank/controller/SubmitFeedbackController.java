package com.bank.controller;

import com.bank.service.FeedbackService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;

public class SubmitFeedbackController {
    public TextArea content;

    FeedbackService feedbackService = new FeedbackService();

    public void confirm(ActionEvent actionEvent) {
        String contentText = content.getText();
        if (Utils.verifyIsEmpty(contentText, "Content")) {
            return;
        }
        contentText = contentText.replaceAll("\n", "\\\\n");

        if (feedbackService.save(contentText)) {
            Utils.showPrompt("Submit Successful", "Success");
        } else {
            Utils.showPrompt("Failed to Submit", "Error");
        }
    }
}
