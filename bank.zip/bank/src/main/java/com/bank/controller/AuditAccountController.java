package com.bank.controller;

import com.bank.entity.AccountApply;
import com.bank.service.AccountService;
import com.bank.utils.Utils;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class AuditAccountController {

    public TableView<AccountApply> tableView;
    public TableColumn<AccountApply, String> username;
    public TableColumn<AccountApply, String> type;
    public TableColumn<AccountApply, String> applyTime;
    AccountService accountService = new AccountService();

    public void initialize() {
        username.setCellValueFactory(new PropertyValueFactory<>("username"));
        type.setCellValueFactory(new PropertyValueFactory<>("type"));
        applyTime.setCellValueFactory(new PropertyValueFactory<>("applyTime"));
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        tableView.setItems(FXCollections.observableArrayList(accountService.findAllUnauditedApply()));
    }

    public void pass(ActionEvent actionEvent) {
        audit(1);
    }

    private void audit(int result) {
        AccountApply selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Utils.showPrompt("Please select a row.", "Error");
            return;
        }
        selectedItem.setStatus(result);
        if (accountService.audit(selectedItem)) {
            Utils.showPrompt("Audit Successful", "Success");
        } else {
            Utils.showPrompt("Failed to Audit", "Error");
        }
        tableView.setItems(FXCollections.observableArrayList(accountService.findAllUnauditedApply()));
    }

    public void refuse(ActionEvent actionEvent) {
        audit(2);
    }
}
