package com.bank.controller;

import com.bank.entity.Feedback;
import com.bank.service.FeedbackService;
import javafx.collections.FXCollections;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class AllFeedbackController {

    public TableView<Feedback> tableView;
    public TableColumn<Feedback, String> userName;
    public TableColumn<Feedback, String> content;
    public TableColumn<Feedback, String> time;

    FeedbackService feedbackService = new FeedbackService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        userName.setCellValueFactory(new PropertyValueFactory<>("username"));
        content.setCellValueFactory(new PropertyValueFactory<>("content"));
        time.setCellValueFactory(new PropertyValueFactory<>("time"));
        tableView.setItems(FXCollections.observableArrayList(feedbackService.findAllFeedBack()));
    }
}
