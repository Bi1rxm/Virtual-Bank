package com.bank.controller;

import com.bank.entity.Task;
import com.bank.service.TaskService;
import com.bank.utils.Utils;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class AuditCompletedTaskController {

    public TableView<Task> tableView;
    public TableColumn id;
    public TableColumn description;
    public TableColumn dueDate;
    public TableColumn reward;
    public TableColumn userName;

    TaskService taskService = new TaskService();

    public void initialize() {
        Label placeholderLabel = new Label("No Data Available");
        tableView.setPlaceholder(placeholderLabel);
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        description.setCellValueFactory(new PropertyValueFactory<>("description"));
        dueDate.setCellValueFactory(new PropertyValueFactory<>("dueDate"));
        reward.setCellValueFactory(new PropertyValueFactory<>("reward"));
        userName.setCellValueFactory(new PropertyValueFactory<>("receiver"));
        tableView.setItems(FXCollections.observableArrayList(taskService.findAllCompletedTask()));
    }

    public void pass(ActionEvent actionEvent) {
        audit("pass", "Pass");
    }

    public void reject(ActionEvent actionEvent) {
        audit("reject", "Reject");
    }

    public void audit(String result, String prompt) {
        Task selectedItem = tableView.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            Utils.showPrompt("Please select a row.", "Error");
            return;
        }
        if (taskService.auditCompletedTask(selectedItem, result)) {
            Utils.showPrompt(prompt + " Successful", "Success");
            tableView.setItems(FXCollections.observableArrayList(taskService.findAllCompletedTask()));
        } else {
            Utils.showPrompt("Failed to " + prompt, "Error");
        }
    }
}
