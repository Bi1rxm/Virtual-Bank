package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.Config;
import com.bank.service.ConfigService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

public class SetInterestRate {

    public TextField interestRate;

    ConfigService configService = new ConfigService();
    Config interestRateConfig ;

    public void initialize() {
        interestRateConfig = configService.findConfigByType("interestRate", null);
        if (interestRateConfig != null) {
            interestRate.setText(interestRateConfig.getValue());
        }
    }

    public void confirm(ActionEvent actionEvent) {
        String interestRateText = interestRate.getText();
        if (!Utils.isNumber(interestRateText)) {
            Utils.showPrompt("Interest rate is invalid.", "Error");
            return;
        }
        double interestRateInDouble = Double.parseDouble(interestRateText);
        if (interestRateInDouble >= 0 && interestRateInDouble < 1) {
            Config interestRateConfig = configService.findConfigByType("interestRate", null);
            if (interestRateConfig == null) {
                Config newInterestRateConfig = new Config("interestRate", interestRateText, Cache.getInstance().getLoginUser().getUsername());
                if (configService.save(newInterestRateConfig)) {
                    this.interestRateConfig = newInterestRateConfig;
                    Utils.showPrompt("Set Successful", "Success");
                } else {
                    Utils.showPrompt("Failed to Set", "Error");
                }
            } else {
                if (configService.update(interestRateConfig, interestRateText)) {
                    Utils.showPrompt("Set Successful", "Success");
                } else {
                    Utils.showPrompt("Failed to Set", "Error");
                }
            }
        } else {
            Utils.showPrompt("Interest rate should be in the interval [0, 1).", "Error");
        }
    }
}
