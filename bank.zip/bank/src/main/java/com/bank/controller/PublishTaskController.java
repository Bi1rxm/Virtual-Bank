package com.bank.controller;

import com.bank.cache.Cache;
import com.bank.entity.Task;
import com.bank.entity.User;
import com.bank.service.TaskService;
import com.bank.service.UserService;
import com.bank.utils.Utils;
import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class PublishTaskController {

    public DatePicker dueDate;
    public TextArea description;
    public VBox receiverContainer;
    public TextField reward;

    UserService userService = new UserService();

    TaskService taskService = new TaskService();

    public void initialize() {
        List<User> allCustomer = userService.findUserByRole("customer");
        if (allCustomer != null && allCustomer.size() > 0) {
            for (User user : allCustomer) {
                receiverContainer.getChildren().add(new CheckBox(user.getUsername()));
            }
        }
    }

    public void confirm(ActionEvent actionEvent) {
        LocalDate dueDateValue = dueDate.getValue();
        String descriptionText = description.getText();
        String rewardText = reward.getText();
        List<String> receivers = new ArrayList<>();
        for (Node child : receiverContainer.getChildren()) {
            if (child instanceof CheckBox) {
                CheckBox checkBox = (CheckBox) child;
                if (checkBox.isSelected()) {
                    receivers.add(checkBox.getText());
                }
            }
        }
        if (dueDateValue == null) {
            Utils.showPrompt("Due date is empty.", "Error");
            return;
        }
        if (Utils.verifyIsEmpty(descriptionText, "Description")) {
            return;
        }
        if (!Utils.isNumber(rewardText)) {
            Utils.showPrompt("Reward is invalid.", "Error");
            return;
        }
        if (receivers.size() == 0) {
            Utils.showPrompt("No receiver is selected.", "Error");
            return;
        }

        String publisher = Cache.getInstance().getLoginUser().getUsername();
        for (String receiver : receivers) {
            Task task = new Task(publisher, descriptionText, dueDateValue.format(
                    DateTimeFormatter.ofPattern("yyyy-MM-dd")), receiver, Double.parseDouble(rewardText));
            taskService.save(task);
        }
        Utils.showPrompt("Publish Successful", "Success");
    }
}
