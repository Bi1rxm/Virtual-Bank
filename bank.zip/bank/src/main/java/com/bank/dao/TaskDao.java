package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.Config;
import com.bank.entity.Feedback;
import com.bank.entity.Task;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TaskDao {

    private static final String fileName = Cache.dbBasePath + "task.txt";

    public boolean save(Task task) {
        try {
            FileUtils.writeFile(fileName, task.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + task);
            return false;
        }
        return true;
    }

    public boolean update(Task task) {
        try {
            FileUtils.updateFile(fileName, task.getId(), task.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + task);
            return false;
        }
        return true;
    }

    public List<Task> findAllTask() {
        List<Task> result = new ArrayList<Task>();
        List<String> accountInStringList = FileUtils.readFile(fileName);
        if (accountInStringList.size() > 0) {
            for (String line : accountInStringList) {
                String[] arr = line.split(",");
                result.add(new Task(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], Double.parseDouble(arr[6])));
            }
        }
        return result;
    }
}
