package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.User;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    private static final String fileName = Cache.dbBasePath + "user.txt";

    public User findUserByUserName(String username) {
        List<String> userInStringList = FileUtils.readFile(fileName);
        if (userInStringList.size() > 0) {
            for (String line : userInStringList) {
                String[] arr = line.split(",");
                if (arr[1].equals(username)) {
                    return new User(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], arr[8]);
                }
            }
        }
        return null;
    }

    public boolean save(User user) {
        try {
            FileUtils.writeFile(fileName, user.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is : " + user);
            return false;
        }
        return true;
    }

    public List<User> findAllUser() {
        List<User> result = new ArrayList<>();
        List<String> userInStringList = FileUtils.readFile(fileName);
        if (userInStringList.size() > 0) {
            for (String line : userInStringList) {
                String[] arr = line.split(",");
                result.add(new User(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], arr[8]));
            }
        }
        return result;
    }

    public boolean update(User selectedItem) {
        try {
            FileUtils.updateFile(fileName, selectedItem.getId(), selectedItem.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + selectedItem);
            return false;
        }
        return true;
    }
}
