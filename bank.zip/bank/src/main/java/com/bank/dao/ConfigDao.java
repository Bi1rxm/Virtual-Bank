package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.Config;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.List;

public class ConfigDao {

    private static final String fileName = Cache.dbBasePath + "config.txt";

    public boolean save(Config config) {
        try {
            FileUtils.writeFile(fileName, config.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + config);
            return false;
        }
        return true;
    }

    public Config findConfigByType(String type, String username) {
        List<String> configInStringList = FileUtils.readFile(fileName);
        if (configInStringList.size() > 0) {
            for (String line : configInStringList) {
                String[] arr = line.split(",");
                if (arr[1].equals(type)) {
                    if (username != null && username.trim().length() != 0) {
                        if (username.equals(arr[3])) {
                            return new Config(arr[0], arr[1], arr[2], arr[3]);
                        }
                    } else {
                        return new Config(arr[0], arr[1], arr[2], arr[3]);
                    }
                }
            }
        }
        return null;
    }

    public boolean update(Config config) {
        try {
            FileUtils.updateFile(fileName, config.getId(), config.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + config);
            return false;
        }
        return true;
    }
}
