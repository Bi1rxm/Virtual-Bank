package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.AccountApply;
import com.bank.entity.TransferHistory;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class TransferHistoryDao {

    private static final String fileName = Cache.dbBasePath + "transferHistory.txt";

    public boolean save(TransferHistory transferHistory) {
        try {
            FileUtils.writeFile(fileName, transferHistory.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + transferHistory);
            return false;
        }
        return true;
    }

    public List<TransferHistory> findAllTransferHistory() {
        List<TransferHistory> result = new ArrayList<TransferHistory>();
        List<String> historyInStringList = FileUtils.readFile(fileName);
        if (historyInStringList.size() > 0) {
            for (String line : historyInStringList) {
                String[] arr = line.split(",");
                result.add(new TransferHistory(arr[0], arr[1], Double.parseDouble(arr[2]), arr[3], arr[4], arr[5]));
            }
        }
        return result;
    }
}
