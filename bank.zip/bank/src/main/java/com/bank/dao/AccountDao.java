package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AccountDao {

    private static final String fileName = Cache.dbBasePath + "account.txt";

    public Account findAccountByTypeAndUsername(String type, String username) {
        List<String> accountInStringList = FileUtils.readFile(fileName);
        if (accountInStringList.size() > 0) {
            for (String line : accountInStringList) {
                String[] arr = line.split(",");
                if (arr[1].equals(type) && arr[4].equals(username)) {
                    return new Account(arr[0], arr[1], arr[2], arr[3], arr[4], Double.valueOf(arr[5]), arr[6]);
                }
            }
        }
        return null;
    }

    public boolean save(Account account) {
        try {
            FileUtils.writeFile(fileName, account.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + account);
            return false;
        }
        return true;
    }

    public List<Account> findAllAccount() {
        List<Account> result = new ArrayList<Account>();
        List<String> accountInStringList = FileUtils.readFile(fileName);
        if (accountInStringList.size() > 0) {
            for (String line : accountInStringList) {
                String[] arr = line.split(",");
                result.add(new Account(arr[0], arr[1], arr[2], arr[3], arr[4], Double.valueOf(arr[5]), arr[6]));
            }
        }
        return result;
    }

    public boolean update(Account account) {
        try {
            FileUtils.updateFile(fileName, account.getId(), account.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is : " + account);
            return false;
        }
        return true;
    }

    public List<Account> findAccountByType(String type) {
        return findAllAccount().stream().filter(account -> account.getType().equals(type)).toList();
    }

    public boolean delete(Account account) {
        try {
            FileUtils.deleteFile(Arrays.asList(new String[]{account.getId()}), fileName);
        } catch (IOException e) {
            System.out.println("Delete error, Data is: " + account);
            return false;
        }
        return true;
    }

    public List<String> findAccountNumberByUsername(String username) {
        List<String> result = new ArrayList<String>();
        for (Account account : findAllAccount()) {
            if (account.getUsername().equals(username)) {
                result.add(account.getNumber());
            }
        }
        return result;
    }

    public Account findAccountByNumber(String number) {
        List<String> accountInStringList = FileUtils.readFile(fileName);
        if (accountInStringList.size()>0) {
            for (String line : accountInStringList) {
                String[] arr = line.split(",");
                if (arr[2].equals(number)) {
                    return new Account(arr[0], arr[1], arr[2], arr[3], arr[4], Double.valueOf(arr[5]), arr[6]);
                }
            }
        }
        return null;
    }
}
