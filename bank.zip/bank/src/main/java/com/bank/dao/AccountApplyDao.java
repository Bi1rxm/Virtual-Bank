package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.Account;
import com.bank.entity.AccountApply;
import com.bank.entity.User;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccountApplyDao {

    private static final String fileName = Cache.dbBasePath + "accountApply.txt";

    public AccountApply findAccountByTypeAndUsername(String type, String username) {
        List<String> accountInStringList = FileUtils.readFile(fileName);
        if (accountInStringList.size() > 0) {
            for (String line : accountInStringList) {
                String[] arr = line.split(",");
                if (arr[3].equals(type) && arr[5].equals(username) && "0".equals(arr[4])) {
                    return new AccountApply(arr[0], arr[1], arr[2], arr[3], Integer.valueOf(arr[4]), arr[5]);
                }
            }
        }
        return null;
    }

    public boolean save(AccountApply accountApply) {
        try {
            FileUtils.writeFile(fileName, accountApply.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + accountApply);
            return false;
        }
        return true;
    }

    public List<AccountApply> findAllUnauditedApply() {
        return findAllApply().stream().filter(account -> account.getStatus() == 0).toList();
    }

    public List<AccountApply> findAllApply() {
        List<AccountApply> result = new ArrayList<>();
        List<String> userInStringList = FileUtils.readFile(fileName);
        if (userInStringList.size() > 0) {
            for (String line : userInStringList) {
                String[] arr = line.split(",");
                result.add(new AccountApply(arr[0], arr[1], arr[2], arr[3], Integer.valueOf(arr[4]), arr[5]));
            }
        }
        return result;
    }

    public boolean update(AccountApply accountApply) {
        try {
            FileUtils.updateFile(fileName, accountApply.getId(), accountApply.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + accountApply);
            return false;
        }
        return true;
    }
}
