package com.bank.dao;

import com.bank.cache.Cache;
import com.bank.entity.Feedback;
import com.bank.utils.FileUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDao {

    private static final String fileName = Cache.dbBasePath + "feedback.txt";

    public boolean save(Feedback feedback) {
        try {
            FileUtils.writeFile(fileName, feedback.toString());
        } catch (IOException e) {
            System.out.println("Write error, Data is: " + feedback);
            return false;
        }
        return true;
    }

    public List<Feedback> findAllFeedBack() {
        List<Feedback> result = new ArrayList<Feedback>();
        List<String> accountInStringList = FileUtils.readFile(fileName);
        if (accountInStringList.size() > 0) {
            for (String line : accountInStringList) {
                String[] arr = line.split(",");
                result.add(new Feedback(arr[0], arr[1], arr[2], arr[3]));
            }
        }
        return result;
    }
}
