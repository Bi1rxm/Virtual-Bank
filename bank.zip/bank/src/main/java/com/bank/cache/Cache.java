package com.bank.cache;

import com.bank.entity.Menu;
import com.bank.entity.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Application Cache Class, store some configuration items
 */
public class Cache {

    /**
     * All menu collections
     */
    private List<Menu> menuList = new ArrayList<>();

    /**
     * Directory on the hard drive corresponding to the database
     */
    public static final String dbBasePath = "E:\\BUPT\\6th_sem\\Software Engineering\\Group Project\\bank\\database\\";

    /**
     * Cache Class Singleton
     */
    private static final Cache INSTANCE = new Cache();

    /**
     * Get the singleton object
     * @return cache singleton object
     */
    public static Cache getInstance() {
        return INSTANCE;
    }

    /**
     * Constructor initialises the cache
     */
    private Cache() {
        menuList.add(new Menu("Profile", "", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Modify Basics", "modifyBasicInfo.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Change Password", "changePassword.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Account", "", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Apply Account", "applyAccount.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("My Account", "myAccount.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Audit Account", "auditAccount.fxml", new String[] {"employee"}));
        menuList.add(new Menu("Manage Account", "accountManagement.fxml", new String[] {"employee"}));
        menuList.add(new Menu("Transfer", "", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Transfer Money", "transferMoney.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Transaction History", "transferHistory.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Task", "", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Publish Task", "publishTask.fxml", new String[] {"employee"}));
        menuList.add(new Menu("My Task", "myTask.fxml", new String[] {"customer"}));
        menuList.add(new Menu("Completed Task", "myCompletedTask.fxml", new String[] {"customer"}));
        menuList.add(new Menu("Audit Completed Task", "auditCompletedTask.fxml", new String[] {"employee"}));
        menuList.add(new Menu("Others", "", new String[] {"admin", "customer", "employee"}));
        menuList.add(new Menu("Set Goals", "setGoal.fxml", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Set Interest Rate", "setInterestRate.fxml", new String[] {"employee"}));
        menuList.add(new Menu("Quit","", new String[] {"admin", "employee", "customer"}));
        menuList.add(new Menu("Feedback","", new String[] {"customer", "employee"}));
        menuList.add(new Menu("Submit Feedback", "submitFeedback.fxml", new String[] {"customer"}));
        menuList.add(new Menu("All Feedback", "allFeedback.fxml", new String[] {"employee"}));
        menuList.add(new Menu("Management", "", new String[] {"admin"}));
        menuList.add(new Menu("User Management", "userManagement.fxml", new String[] {"admin"}));
    }

    private User loginUser;

    public User getLoginUser() {
        return loginUser;
    }

    /**
     * Configure the current login user
     * @param user login user
     */
    public void setLoginUser(User user) {
        this.loginUser = user;
    }

    /**
     * Get the menu mapping corresponding to the current login user's role
     * @return all menu mapping of the current user
     */
    public Map<String,Menu> getRoleMenu() {
        Map<String,Menu> result = new HashMap<>();
        for (Menu menu : menuList) {
            if (menu.getRoles().contains(loginUser.getRole())) {
                result.put(menu.getName(), menu);
            }
        }
        return result;
    }

    /**
     * Get menu by name
     * @param name menu name
     * @return Menu mapping for the current name
     */
    public Menu getMenu(String name) {
        for (Menu menu : menuList) {
            if (menu.getName().equals(name)) {
                return menu;
            }
        }
        return null;
    }
}
