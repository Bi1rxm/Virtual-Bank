package com.bank.service;

import com.bank.cache.Cache;
import com.bank.dao.TaskDao;
import com.bank.dao.TransferHistoryDao;
import com.bank.entity.Account;
import com.bank.entity.Task;
import com.bank.entity.TransferHistory;

import java.util.List;

public class TaskService {

    TaskDao taskDao = new TaskDao();

    TransferHistoryDao transferHistoryDao = new TransferHistoryDao();

    AccountService accountService = new AccountService();

    public boolean save(Task task) {
        return taskDao.save(task);
    }

    public List<Task> findAllWaitForCompletionTask() {
        return taskDao.findAllTask().stream().filter(task -> task.getStatus().equals("published") &&
                task.getReceiver().equals(Cache.getInstance().getLoginUser().getUsername())).toList();
    }

    public boolean complete(Task task) {
        task.setStatus("completed");
        return taskDao.update(task);
    }

    public List<Task> findAllCompletedTask() {
        return taskDao.findAllTask().stream().filter(task -> task.getStatus().equals("completed")).toList();
    }

    public boolean auditCompletedTask(Task task, String result) {
        task.setStatus(result);
        if (result.equals("pass")) {
            Account account = accountService.findAccountByTypeAndUsername("current", task.getReceiver());
            account.setBalance(account.getBalance() + task.getReward());
            accountService.update(account);
            transferHistoryDao.save(new TransferHistory("System", task.getReward(), "reward", account.getNumber()));
        }
        return taskDao.update(task);
    }

    public List<Task> findAllAuditedTask() {
        return taskDao.findAllTask().stream().filter(task -> (task.getStatus().equals("completed")||task.getStatus().equals("pass") || task.getStatus().equals("reject")) &&
                task.getReceiver().equals(Cache.getInstance().getLoginUser().getUsername())).toList();
    }
}
