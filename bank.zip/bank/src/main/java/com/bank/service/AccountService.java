package com.bank.service;

import com.bank.cache.Cache;
import com.bank.dao.AccountApplyDao;
import com.bank.dao.AccountDao;
import com.bank.dao.TransferHistoryDao;
import com.bank.entity.Account;
import com.bank.entity.AccountApply;
import com.bank.entity.Config;
import com.bank.entity.TransferHistory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AccountService {

    AccountDao accountDao = new AccountDao();

    ConfigService configService = new ConfigService();

    AccountApplyDao accountApplyDao = new AccountApplyDao();

    TransferHistoryDao transferHistoryDao = new TransferHistoryDao();

    public Account findAccountByTypeAndUsername(String type, String username) {
        return accountDao.findAccountByTypeAndUsername(type, username);
    }

    public AccountApply findApplyByTypeAndUsername(String type, String username) {
        return accountApplyDao.findAccountByTypeAndUsername(type, username);
    }

    public boolean save(AccountApply accountApply) {
        return accountApplyDao.save(accountApply);
    }

    public List<AccountApply> findAllUnauditedApply() {
        return accountApplyDao.findAllUnauditedApply();
    }

    public boolean audit(AccountApply accountApply) {
        if (accountApplyDao.update(accountApply)) {
            if (accountApply.getStatus() == 1) {
                if (accountDao.save(new Account(accountApply))) {
                    return true;
                }
            }
            return true;
        }
        return false;
    }

    public List<Account> findAllAccount() {
        return accountDao.findAllAccount();
    }

    public boolean saveMoney(double amount, Account account) {
        account.setBalance(account.getBalance() + amount);
        return accountDao.update(account);
    }

    public boolean withdrawMoney(Double amount, Account account) {
        account.setBalance(account.getBalance() - amount);
        return accountDao.update(account);
    }

    public boolean freeze(Account account) {
        account.setStatus("frozen");
        return accountDao.update(account);
    }

    public boolean thaw(Account account) {
        account.setStatus("normal");
        return accountDao.update(account);
    }

    public void settle() {
        Config interestRateConfig = configService.findConfigByType("interestRate", null);
        if (interestRateConfig != null) {
            BigDecimal rate = new BigDecimal(interestRateConfig.getValue());
            List<Account> accountList = accountDao.findAccountByType("saving");
            if (accountList != null && accountList.size() > 0) {
                for (Account account : accountList) {
                    BigDecimal interest = new BigDecimal(account.getBalance()).multiply(rate).setScale(2, RoundingMode.HALF_UP);
                    if (interest.doubleValue() > 0) {
                        account.setBalance(account.getBalance() + interest.doubleValue());
                        accountDao.update(account);
                        transferHistoryDao.save(new TransferHistory("System", interest.doubleValue(), "interest", account.getNumber()));
                    }
                }
            }
        }
    }

    public boolean update(Account account) {
        return accountDao.update(account);
    }

    public boolean delete(Account account) {
        return accountDao.delete(account);
    }

    public List<Map<String, String>> findAllCurrentUserTransferHistory() {
        List<Map<String, String>> result = new ArrayList<Map<String, String>>();
        List<String> accountNumbers = accountDao.findAccountNumberByUsername(Cache.getInstance().getLoginUser().getUsername());
        if (accountNumbers.size() > 0) {
            List<TransferHistory> transferHistoryList = transferHistoryDao.findAllTransferHistory();
            if (transferHistoryList.size() > 0) {
                for (TransferHistory transferHistory : transferHistoryList) {
                    if (accountNumbers.contains(transferHistory.getPayer()) || accountNumbers.contains(transferHistory.getPayee())) {
                        Map<String, String> data = new HashMap<>();
                        if (accountNumbers.contains(transferHistory.getPayer())) {
                            data.put("accountNumber", transferHistory.getPayer());
                            data.put("amount", "-" + transferHistory.getAmount());
                        } else {
                            data.put("accountNumber", transferHistory.getPayee());
                            data.put("amount", "+" + transferHistory.getAmount());
                        }
                        data.put("type", transferHistory.getType());
                        data.put("time", transferHistory.getTime());
                        result.add(data);
                    }
                }
            }
        }
        return result;
    }

    public List<Account> findAllCurrentUserAccount() {
        String username = Cache.getInstance().getLoginUser().getUsername();
        return accountDao.findAllAccount().stream().filter(account -> account.getUsername().equals(username)).toList();
    }

    public Account findAccountByNumber(String number) {
        return accountDao.findAccountByNumber(number);
    }

    public void transferMoney(Account payerAccount, Account payeeAccount, Double amount) {
        payerAccount.setBalance(payerAccount.getBalance() - amount);
        accountDao.update(payerAccount);
        payeeAccount.setBalance(payeeAccount.getBalance() + amount);
        accountDao.update(payeeAccount);
        transferHistoryDao.save(new TransferHistory(payerAccount.getNumber(), amount, "transfer", payeeAccount.getNumber()));
    }
}
