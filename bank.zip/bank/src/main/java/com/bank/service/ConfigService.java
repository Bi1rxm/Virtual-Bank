package com.bank.service;

import com.bank.dao.ConfigDao;
import com.bank.entity.Config;

public class ConfigService {

    ConfigDao configDao = new ConfigDao();

    public boolean save(Config config) {
        return configDao.save(config);
    }

    public Config findConfigByType(String type, String username) {
        return configDao.findConfigByType(type, username);
    }

    public boolean update(Config config, String value) {
        config.setValue(value);
        return configDao.update(config);
    }
}
