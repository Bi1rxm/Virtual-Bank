package com.bank.service;

import com.bank.cache.Cache;
import com.bank.dao.FeedbackDao;
import com.bank.entity.Feedback;

import java.util.List;

public class FeedbackService {

    FeedbackDao feedbackDao = new FeedbackDao();

    public boolean save(String content) {
        Feedback feedback = new Feedback(Cache.getInstance().getLoginUser().getUsername(), content);
        return feedbackDao.save(feedback);
    }

    public List<Feedback> findAllFeedBack() {
        return feedbackDao.findAllFeedBack();
    }
}
