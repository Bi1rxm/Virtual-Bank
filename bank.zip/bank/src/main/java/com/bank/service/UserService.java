package com.bank.service;

import com.bank.cache.Cache;
import com.bank.dao.UserDao;
import com.bank.entity.User;

import java.util.List;

public class UserService {

    UserDao userDao = new UserDao();

    public User login(String username, String password) {
        if (username.equals("admin") && password.equals("123456")){
            User user = new User("admin", password, "admin", "", "admin");
            Cache.getInstance().setLoginUser(user);
            return user;
        } else {
            User user = findUserByUserName(username);
            if ((user != null) && user.getPassword().equals(password)) {
                Cache.getInstance().setLoginUser(user);
                return user;
            }
        }
        return null;
    }

    public User findUserByUserName(String username) {
        return userDao.findUserByUserName(username);
    }

    public boolean save(User user) {
        return userDao.save(user);
    }

    public List<User> findAllUser() {
        return userDao.findAllUser();
    }

    public boolean update(User selectedItem) {
        return userDao.update(selectedItem);
    }

    public List<User> findUserByRole(String role) {
        return userDao.findAllUser().stream().filter(user -> user.getRole().equals(role)).toList();
    }
}
