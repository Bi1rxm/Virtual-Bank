package com.bank.entity;

import java.util.UUID;

public class Config {

    private String id;

    private String type;

    private String value;

    private String username;

    public Config(String id, String type, String value, String username) {
        this.id = id;
        this.type = type;
        this.value = value;
        this.username = username;
    }

    public Config(String type, String value, String username) {
        this.id = UUID.randomUUID().toString();
        this.type = type;
        this.value = value;
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return id +","+ type +","+ value +","+ username;
    }
}
