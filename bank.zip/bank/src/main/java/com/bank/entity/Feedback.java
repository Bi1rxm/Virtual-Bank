package com.bank.entity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class Feedback {

    private String id;

    private String time;

    private String username;

    private String content;

    public Feedback(String username, String content) {
        this.id = UUID.randomUUID().toString();
        this.time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.username = username;
        this.content = content;
    }

    public Feedback(String id, String time, String username, String content) {
        this.id = id;
        this.time = time;
        this.username = username;
        this.content = content.replaceAll("\\\\n","\n");
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return id +","+ time +","+ username +","+ content;
    }
}
