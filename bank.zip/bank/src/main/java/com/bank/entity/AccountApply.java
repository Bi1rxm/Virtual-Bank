package com.bank.entity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class AccountApply {

    private String id;

    private String password;

    private String applyTime;

    private String type;

    private int status;

    private String username;

    public AccountApply(String password, String type, String username) {
        this.id = UUID.randomUUID().toString();
        this.status = 0;
        this.applyTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.password = password;
        this.type = type;
        this.username = username;
    }

    public AccountApply(String id, String password, String applyTime, String type, int status, String username) {
        this.id = id;
        this.password = password;
        this.applyTime = applyTime;
        this.type = type;
        this.status = status;
        this.username = username;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(String applyTime) {
        this.applyTime = applyTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return id +","+ password +","+ applyTime +","+ type +","+ status +","+ username;
    }
}
