package com.bank.entity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

public class Account {

    private String id;

    private String type ;

    private String number;

    private String password;

    private String username;

    private double balance;

    private String status;

    public Account(AccountApply accountApply) {
        this.id = UUID.randomUUID().toString();
        this.type = accountApply.getType();
        this.number = System.nanoTime()+"";
        this.password = accountApply.getPassword();
        this.username = accountApply.getUsername();
        this.balance = 0.0;
        this.status = "normal";
    }

    public Account(String id, String type, String number, String password, String username, double balance, String status) {
        this.id = id;
        this.type = type;
        this.number = number;
        this.password = password;
        this.username = username;
        this.balance = balance;
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = new BigDecimal(balance).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public String toString() {
        return id +","+ type +","+ number +","+ password +","+ username +","+ balance +","+ status;
    }
}
