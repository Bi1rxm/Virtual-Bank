package com.bank.entity;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class TransferHistory {

    private String id;

    private String payer;

    private double amount;

    private String type;

    private String payee;

    private String time;

    public TransferHistory(String payer, double amount, String type, String payee) {
        this.id = UUID.randomUUID().toString();
        this.time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        this.payer = payer;
        this.amount = amount;
        this.type = type;
        this.payee = payee;
    }

    public TransferHistory(String id, String payer, double amount, String type, String payee, String time) {
        this.id = id;
        this.payer = payer;
        this.amount = amount;
        this.type = type;
        this.payee = payee;
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPayer() {
        return payer;
    }

    public void setPayer(String payer) {
        this.payer = payer;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPayee() {
        return payee;
    }

    public void setPayee(String payee) {
        this.payee = payee;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return id +","+ payer +","+ amount +","+ type +","+ payee +","+ time;
    }
}
