package com.bank.entity;

import java.util.UUID;

public class Task {

    private String id;

    private String publisher;

    private String description;

    private String dueDate;

    private String  receiver;

    private String  status;

    private double reward;

    public Task(String id, String publisher, String description, String dueDate, String receiver, String  status, double reward) {
        this.id = id;
        this.publisher = publisher;
        this.description = description.replaceAll("\\\\n", "\n");
        this.dueDate = dueDate;
        this.receiver = receiver;
        this.status = status;
        this.reward = reward;
    }

    public Task(String publisher, String description, String dueDate, String receiver, double reward) {
        this.id = UUID.randomUUID().toString();
        this.publisher = publisher;
        this.description = description;
        this.dueDate = dueDate;
        this.receiver = receiver;
        this.reward = reward;
        this.status = "published";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getReward() {
        return reward;
    }

    public void setReward(double reward) {
        this.reward = reward;
    }

    @Override
    public String toString() {
        return id +","+ publisher +","+ description.replaceAll("\n", "\\\\n") +","+ dueDate +","+ receiver +","+ status +","+ reward;
    }
}
