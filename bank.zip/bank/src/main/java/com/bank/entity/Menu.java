package com.bank.entity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Menu {

    private String name;

    private String templateName;

    private String[] roles;

    public Menu(String name, String templateName, String[] roles) {
        this.name = name;
        this.templateName = templateName;
        this.roles = roles;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public List<String> getRoles() {
        return Arrays.asList(roles) == null ? new ArrayList<>() : Arrays.asList(roles);
    }

    public void setRoles(String[] roles) {
        this.roles = roles;
    }
}
