package com.bank;

import com.bank.cache.Cache;
import com.bank.utils.Utils;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;

public class App extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        File file = new File(Cache.dbBasePath);
        if (!file.exists()) {
            file.mkdirs();
        }
        Utils.showPage("login.fxml", 400, 260, "Virtual Bank");
    }

    public static void main(String[] args) {
        launch();
    }
}