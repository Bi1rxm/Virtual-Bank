package com.bank.test;

import com.bank.cache.Cache;
import com.bank.entity.User;
import com.bank.service.UserService;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;

public class UnitTest {
    static UserService userService;

    @BeforeAll
    public static void init(){
        userService = new UserService();
    }

    @Test
    public void testAdminLogin() {
        // Before a successful login getLoginUser() method should return null
        assertTrue(Cache.getInstance().getLoginUser() == null);
        // Test admin login
        User loginUser = userService.login("admin", "123456");
        assertFalse(Cache.getInstance().getLoginUser() == null);
        assertTrue(loginUser.getRole().equals("admin"));
        assertTrue(loginUser == Cache.getInstance().getLoginUser());
    }

    @Test
    public void testNormalRoleLogin() {
        // Test wrong username
        assertTrue(Cache.getInstance().getLoginUser() == null);
        User user = userService.login("WrongName", "123456");
        assertTrue(user == null);
        // Test wrong password
        assertTrue(Cache.getInstance().getLoginUser() == null);
        user = userService.login("cus2", "123456");
        assertTrue(user == null);
        // Test correct password
        assertTrue(Cache.getInstance().getLoginUser() == null);
        user = userService.login("cus2", "123");
        assertTrue(user != null);
    }
}
