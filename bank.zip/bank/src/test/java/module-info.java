module com.bank.test {
    exports com.bank.test;
    requires com.bank;
    requires org.junit.jupiter.api;
}